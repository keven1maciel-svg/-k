import { randomInt } from "node:crypto";
import { EmbedBuilder, type User } from "discord.js";

type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary";

type Clan = {
  name: string;
  rarity: Rarity;
  drawWeight?: number;
};

export type VillageName = "Folha" | "Areia" | "Névoa" | "Nuvem";

type Village = {
  name: VillageName;
  emoji: string;
  primaryElement: Element;
  color: number;
  clans: Clan[];
};

type Element = "Água" | "Fogo" | "Raio" | "Vento" | "Pedra";

const rarityInfo: Record<Rarity, { label: string; emoji: string }> = {
  common: { label: "Comum", emoji: "🟢" },
  uncommon: { label: "Incomum", emoji: "🔵" },
  rare: { label: "Raro", emoji: "🟣" },
  epic: { label: "Épico", emoji: "🟡" },
  legendary: { label: "Lendário", emoji: "🔴" },
};

const rarityWeights: Record<Rarity, number> = {
  common: 8,
  uncommon: 12,
  rare: 8,
  epic: 6,
  legendary: 4,
};

const elementEmojis: Record<Element, string> = {
  Água: "💧",
  Fogo: "🔥",
  Raio: "⚡",
  Vento: "🌪️",
  Pedra: "🪨",
};

const allElements: Element[] = ["Água", "Fogo", "Raio", "Vento", "Pedra"];

const villages: Village[] = [
  {
    name: "Folha",
    emoji: "🍃",
    primaryElement: "Fogo",
    color: 0x3c9b61,
    clans: [
      { name: "Néctar (Mitsubara)", rarity: "common" },
      { name: "Sound (TremTing)", rarity: "common" },
      { name: "Kenichi (Rock)", rarity: "uncommon" },
      { name: "Okami (Inuzuka)", rarity: "uncommon" },
      { name: "Jayramaki", rarity: "legendary" },
      { name: "Shado (Nara)", rarity: "rare" },
      { name: "Kerada (Akimichi)", rarity: "rare" },
      { name: "Saberu (Hatake)", rarity: "rare" },
      { name: "Ryuji-Kenichi (Maito)", rarity: "rare" },
      { name: "Jokei (Hyuga)", rarity: "epic" },
      { name: "Kaijin (Sarutobi)", rarity: "epic" },
      { name: "Shizen (Senju)", rarity: "epic" },
      { name: "Azarashi (Uzumaki)", rarity: "legendary" },
      { name: "Akuma (Uchiha)", rarity: "legendary" },
      { name: "Minakaze (Namikaze)", rarity: "legendary" },
    ],
  },
  {
    name: "Areia",
    emoji: "🏜️",
    primaryElement: "Vento",
    color: 0xc18a43,
    clans: [
      { name: "Dust (Dust)", rarity: "common" },
      { name: "Typhoon (Typhon)", rarity: "common" },
      { name: "Paper (Kamigawa)", rarity: "uncommon" },
      { name: "Minakami (Minakami)", rarity: "uncommon" },
      { name: "Scorch (Shakuton)", rarity: "uncommon" },
      { name: "Cobra (Hebikage)", rarity: "epic" },
      { name: "Kazekage (Sabaku — Areia)", rarity: "epic" },
      { name: "Clay (Bahukara)", rarity: "epic" },
    ],
  },
  {
    name: "Névoa",
    emoji: "🌫️",
    primaryElement: "Água",
    color: 0x3296a8,
    clans: [
      { name: "Mud (Mud)", rarity: "common" },
      { name: "Lava (Terumi)", rarity: "common" },
      { name: "Tsunami (Shizen)", rarity: "uncommon" },
      { name: "Bubble (Awanami)", rarity: "uncommon" },
      { name: "Ice (Yuki)", rarity: "rare" },
      { name: "Dangan (Hozuki)", rarity: "rare" },
      { name: "Wanziame (Hoshigaki)", rarity: "epic" },
      { name: "Kokotsu (Kaguya)", rarity: "epic" },
      { name: "Glacier (Yuki)", rarity: "legendary" },
      { name: "Eternal (Jashin)", rarity: "legendary" },
    ],
  },
  {
    name: "Nuvem",
    emoji: "☁️",
    primaryElement: "Raio",
    color: 0x6672c8,
    clans: [
      { name: "Smoke (Moku)", rarity: "common" },
      { name: "Web (Kumo)", rarity: "common" },
      { name: "Bolt (Kaminari)", rarity: "common" },
      { name: "Boil (Fumetsu)", rarity: "common" },
      { name: "Hair (Jiunko)", rarity: "uncommon" },
      { name: "Ink (Ink)", rarity: "uncommon" },
      { name: "Crystal (Kensshõ)", rarity: "rare" },
      { name: "Storm (Arashi)", rarity: "rare" },
      { name: "Ragnar (Ragnar)", rarity: "epic" },
      { name: "Snakeman (Hebiyõ)", rarity: "epic" },
      { name: "BruceKenichi (Bruce)", rarity: "epic" },
      { name: "Black Lightning (BlackStorm)", rarity: "legendary" },
      { name: "Senko (Senko)", rarity: "legendary", drawWeight: 1 },
      { name: "Ashen Storm", rarity: "legendary", drawWeight: 1 },
    ],
  },
];

export const VILLAGE_REGISTRATION_COMMANDS = [
  {
    name: "registroareia",
    village: "Areia",
    description: "Gera uma ficha da Vila da Areia.",
  },
  {
    name: "registrofolha",
    village: "Folha",
    description: "Gera uma ficha da Vila da Folha.",
  },
  {
    name: "registronuvem",
    village: "Nuvem",
    description: "Gera uma ficha da Vila da Nuvem.",
  },
  {
    name: "registronévoa",
    village: "Névoa",
    description: "Gera uma ficha da Vila da Névoa.",
  },
] as const satisfies readonly {
  name: string;
  village: VillageName;
  description: string;
}[];

const intellectCategories = [
  {
    name: "Normal",
    weight: 50,
    results: ["Normal (81)", "Normal (84)", "Normal (87)"],
  },
  {
    name: "Inteligente",
    weight: 30,
    results: ["Inteligente (140)", "Inteligente (147)"],
  },
  { name: "Gênio", weight: 10, results: ["Gênio (150)"] },
];

const affinityCounts = [
  { count: 2, weight: 20 },
  { count: 3, weight: 4 },
  { count: 4, weight: 1 },
];

function pick<T>(items: readonly T[]): T {
  return items[randomInt(items.length)]!;
}

function pickWeighted<T>(
  items: readonly T[],
  getWeight: (item: T) => number,
): T {
  const totalWeight = items.reduce((total, item) => total + getWeight(item), 0);

  if (totalWeight <= 0) {
    throw new Error("Weighted draw requires at least one positive weight.");
  }

  let roll = randomInt(totalWeight);

  for (const item of items) {
    roll -= getWeight(item);
    if (roll < 0) return item;
  }

  return items[items.length - 1]!;
}

function clanWeight(clan: Clan): number {
  return clan.drawWeight ?? rarityWeights[clan.rarity];
}

function pickClan(clans: readonly Clan[]): Clan {
  if (clans.length === 0) {
    throw new Error("Cannot draw a clan from an empty village.");
  }

  return pickWeighted(clans, clanWeight);
}

function pickUnique<T>(items: readonly T[], count: number): T[] {
  const available = [...items];
  const selected: T[] = [];

  while (selected.length < count && available.length > 0) {
    selected.push(available.splice(randomInt(available.length), 1)[0]!);
  }

  return selected;
}

function pickClans(village: Village, compatibleWithTwo: boolean): Clan[] {
  const firstClan = pickClan(village.clans);
  if (!compatibleWithTwo) return [firstClan];

  const remainingClans = village.clans.filter(
    (clan) => clan.name !== firstClan.name,
  );
  return [firstClan, pickClan(remainingClans)];
}

function formattedDate(): string {
  return new Intl.DateTimeFormat("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "America/Manaus",
  }).format(new Date());
}

export function createFichaEmbed(
  user: User,
  requestedVillage?: VillageName,
): EmbedBuilder {
  const village = requestedVillage
    ? villages.find((entry) => entry.name === requestedVillage)
    : pick(villages);

  if (!village) {
    throw new Error(`Unknown village requested: ${requestedVillage}`);
  }

  const compatibleWithTwo = randomInt(6) === 0;
  const chosenClans = pickClans(village, compatibleWithTwo);
  const affinityCount = pickWeighted(affinityCounts, (result) => result.weight)
    .count;
  const additionalElements = pickUnique(
    allElements.filter((element) => element !== village.primaryElement),
    affinityCount - 1,
  );
  const chosenElements = [village.primaryElement, ...additionalElements];
  const intellectCategory = pickWeighted(
    intellectCategories,
    (category) => category.weight,
  );
  const intellect = pick(intellectCategory.results);
  const targetName = user.globalName ?? user.username;

  return new EmbedBuilder()
    .setColor(village.color)
    .setAuthor({ name: "ARQUIVO SHINOBI  •  FICHA DE RPG" })
    .setTitle("📜 Ficha Shinobi")
    .setDescription(
      `*Ficha sorteada para **${targetName}***\n\n${village.emoji} **Vila da ${village.name}**\nElemento principal: ${elementEmojis[village.primaryElement]} **${village.primaryElement}**`,
    )
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      {
        name: "🗺️ Vila",
        value: `**${village.emoji} ${village.name}**`,
        inline: false,
      },
      {
        name: chosenClans.length === 2 ? "🧬 Clãs" : "🧬 Clã",
        value: chosenClans
          .map((clan) => {
            const rarity = rarityInfo[clan.rarity];
            return `${rarity.emoji} **${clan.name}**  ·  ${rarity.label}`;
          })
          .join("\n\n"),
        inline: false,
      },
      {
        name: "🔗 Compatível com 2 clãs?",
        value: compatibleWithTwo ? "✅ **Sim**" : "▫️ Não",
        inline: false,
      },
      {
        name: "🔮 Afinidade elemental",
        value: `**${affinityCount}/4** ${affinityCount === 1 ? "elemento" : "elementos"}`,
        inline: false,
      },
      {
        name: "🌋 Elementos",
        value: chosenElements
          .map(
            (element, index) =>
              `${elementEmojis[element]} ${element}${index === 0 ? " · principal da vila" : ""}`,
          )
          .join("\n"),
        inline: false,
      },
      {
        name: "🧠 Intelecto",
        value: `**${intellect}**`,
        inline: false,
      },
    )
    .setFooter({ text: `FICHA GERADA • ${formattedDate()} • RPG SHINOBI` })
    .setTimestamp();
}