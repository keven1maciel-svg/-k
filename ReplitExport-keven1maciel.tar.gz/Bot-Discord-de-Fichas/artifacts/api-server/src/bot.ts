import {
  Client,
  Events,
  GatewayIntentBits,
  PermissionFlagsBits,
  SlashCommandBuilder,
} from "discord.js";
import { logger } from "./lib/logger";
import {
  createFichaEmbed,
  VILLAGE_REGISTRATION_COMMANDS,
} from "./bot/ficha";

const token = process.env.DISCORD_BOT_TOKEN;

if (!token) {
  throw new Error(
    "DISCORD_BOT_TOKEN is required to run the Discord bot. Add it in Replit Secrets.",
  );
}

function buildFichaCommand(name: string, description: string) {
  return new SlashCommandBuilder()
    .setName(name)
    .setDescription(description)
    .addUserOption((option) =>
      option
        .setName("usuario")
        .setDescription("Pessoa para quem a ficha será gerada.")
        .setRequired(false),
    );
}

const fichaCommand = buildFichaCommand(
  "verficha",
  "Gera uma ficha aleatória entre todas as vilas.",
);
const villageCommands = VILLAGE_REGISTRATION_COMMANDS.map((command) =>
  buildFichaCommand(command.name, command.description),
);
const fichaCommands = [fichaCommand, ...villageCommands];

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.once(Events.ClientReady, async (readyClient) => {
  try {
    const application = readyClient.application;

    if (!application) {
      throw new Error("Discord application is not available after login.");
    }

    const registeredCommands = await application.commands.fetch();

    for (const commandBuilder of fichaCommands) {
      const commandData = commandBuilder.toJSON();
      const existingCommand = registeredCommands.find(
        (command) => command.name === commandData.name,
      );

      if (existingCommand) {
        await application.commands.edit(existingCommand.id, commandData);
      } else {
        await application.commands.create(commandData);
      }
    }

    const permissions = (
      PermissionFlagsBits.SendMessages | PermissionFlagsBits.EmbedLinks
    ).toString();
    const inviteUrl = new URL("https://discord.com/oauth2/authorize");
    inviteUrl.searchParams.set("client_id", readyClient.user.id);
    inviteUrl.searchParams.set("permissions", permissions);
    inviteUrl.searchParams.set("scope", "bot applications.commands");

    logger.info(
      { bot: readyClient.user.tag, inviteUrl: inviteUrl.toString() },
      "Discord bot is online. Use the invite link to add it to your server.",
    );
  } catch (error) {
    logger.error({ err: error }, "Could not register the /verficha command");
    await readyClient.destroy();
    process.exitCode = 1;
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const villageCommand = VILLAGE_REGISTRATION_COMMANDS.find(
    (command) => command.name === interaction.commandName,
  );
  if (interaction.commandName !== fichaCommand.name && !villageCommand) return;

  try {
    const targetUser =
      interaction.options.getUser("usuario") ?? interaction.user;

    logger.info(
      { hasTargetUser: targetUser.id !== interaction.user.id },
      `Handling /${interaction.commandName} interaction`,
    );

    await interaction.reply({
      embeds: [createFichaEmbed(targetUser, villageCommand?.village)],
    });
  } catch (error) {
    logger.error(
      { err: error, userId: interaction.user.id },
      "Could not send a ficha response",
    );

    if (!interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content:
          "Não consegui enviar a ficha. Confira se tenho permissão para enviar mensagens e embeds neste canal.",
        ephemeral: true,
      });
    }
  }
});

client.on(Events.Error, (error) => {
  logger.error({ err: error }, "Discord client error");
});

process.once("SIGINT", () => {
  client.destroy();
});

process.once("SIGTERM", () => {
  client.destroy();
});

await client.login(token);