import {
  ArrowUpRight,
  Brain,
  Cloud,
  Crown,
  Sparkles,
  Swords,
  Waves,
  Wind,
  Zap,
} from "lucide-react";
import type { ReactNode } from "react";

const elements = [
  { name: "Água", icon: Waves, primary: true },
  { name: "Vento", icon: Wind, primary: false },
  { name: "Raio", icon: Zap, primary: false },
];

function Tag({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "cyan" | "red" | "violet";
}) {
  const tones = {
    neutral: "border-white/10 bg-white/[0.04] text-slate-300",
    cyan: "border-cyan-300/20 bg-cyan-300/10 text-cyan-100",
    red: "border-rose-300/25 bg-rose-300/10 text-rose-100",
    violet: "border-violet-300/20 bg-violet-300/10 text-violet-100",
  };

  return (
    <span
      className={`inline-flex items-center rounded-full border px-3 py-1 text-[11px] font-semibold tracking-wide ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function RegistroFicha() {
  return (
    <main className="flex min-h-screen w-full items-start justify-center bg-[#191b20] px-4 py-7 text-[#eef2f5] sm:px-7 sm:py-10">
      <div className="w-full max-w-[590px]">
        <div className="mb-4 flex items-center gap-3 px-1">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-cyan-200/20 bg-gradient-to-br from-cyan-200/20 to-indigo-300/10 text-cyan-100 shadow-[0_0_24px_rgba(73,203,227,0.12)]">
            <Sparkles size={18} strokeWidth={1.7} />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate text-sm font-semibold tracking-wide text-slate-100">
                Arquivo Shinobi
              </p>
              <span className="rounded bg-[#5865f2] px-1.5 py-0.5 text-[9px] font-black uppercase tracking-widest text-white">
                bot
              </span>
            </div>
            <p className="mt-0.5 text-xs text-slate-500">
              Registro concluído · agora
            </p>
          </div>
          <span className="ml-auto self-start pt-1 text-[11px] text-slate-600">
            #fichas
          </span>
        </div>

        <article className="relative isolate overflow-hidden rounded-2xl border border-white/[0.09] bg-[#11171e] shadow-[0_26px_80px_rgba(0,0,0,0.45)]">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 -z-10"
            style={{
              background:
                "radial-gradient(circle at 88% 4%, rgba(43, 171, 198, 0.18), transparent 31%), radial-gradient(circle at 0% 65%, rgba(71, 111, 168, 0.12), transparent 34%)",
            }}
          />
          <div className="absolute inset-y-0 left-0 w-[3px] bg-gradient-to-b from-cyan-200 via-sky-500 to-indigo-500" />

          <div className="relative p-5 sm:p-7">
            <header className="flex items-start justify-between gap-4">
              <div>
                <div className="mb-3 inline-flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.22em] text-cyan-200/75">
                  <span className="h-px w-6 bg-cyan-200/60" />
                  Dossiê de personagem
                </div>
                <h1 className="text-[26px] font-semibold leading-tight tracking-[-0.035em] text-white sm:text-[30px]">
                  Ficha da Névoa
                </h1>
                <p className="mt-2 text-sm text-slate-400">
                  Preparada para{" "}
                  <span className="font-medium text-slate-200">@membro</span>
                </p>
              </div>

              <div className="relative flex h-[72px] w-[72px] shrink-0 items-center justify-center rounded-full border border-cyan-100/15 bg-cyan-200/[0.05] shadow-[inset_0_0_24px_rgba(103,220,240,0.08)]">
                <div className="absolute inset-[6px] rounded-full border border-dashed border-cyan-100/15" />
                <Cloud size={29} strokeWidth={1.4} className="text-cyan-100" />
                <span className="absolute -bottom-1 rounded-full border border-[#11171e] bg-[#18323b] px-2 py-0.5 text-[8px] font-bold uppercase tracking-[0.18em] text-cyan-100">
                  kiri
                </span>
              </div>
            </header>

            <section className="mt-6 rounded-xl border border-cyan-100/10 bg-gradient-to-br from-[#1a3038] via-[#17242e] to-[#171b27] p-4 sm:p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-cyan-100/10 bg-black/20 text-2xl">
                    <Cloud size={24} strokeWidth={1.5} className="text-cyan-100" />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-[0.19em] text-cyan-100/55">
                      Vila
                    </p>
                    <p className="mt-1 text-lg font-semibold text-white">
                      Vila da Névoa
                    </p>
                  </div>
                </div>
                <Tag tone="cyan">Elemento principal · Água</Tag>
              </div>
            </section>

            <section className="mt-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">
                  Linhagem shinobi
                </p>
                <span className="text-[10px] text-slate-600">2 clãs gerados</span>
              </div>
              <div className="grid gap-2.5 sm:grid-cols-2">
                <div className="rounded-xl border border-amber-200/15 bg-gradient-to-br from-amber-100/[0.07] to-transparent p-4">
                  <div className="flex items-center justify-between">
                    <Crown size={15} className="text-rose-200" />
                    <Tag tone="red">Lendário</Tag>
                  </div>
                  <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.17em] text-rose-100/55">
                    Clã principal
                  </p>
                  <h2 className="mt-1 text-lg font-semibold text-white">
                    Glacier
                  </h2>
                  <p className="text-xs text-slate-400">Yuki</p>
                </div>

                <div className="rounded-xl border border-violet-200/15 bg-gradient-to-br from-violet-200/[0.07] to-transparent p-4">
                  <div className="flex items-center justify-between">
                    <Sparkles size={15} className="text-violet-200" />
                    <Tag tone="violet">Raro</Tag>
                  </div>
                  <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.17em] text-violet-100/55">
                    Compatibilidade
                  </p>
                  <h2 className="mt-1 text-lg font-semibold text-white">
                    Ice
                  </h2>
                  <p className="text-xs text-slate-400">Segundo clã · Yuki</p>
                </div>
              </div>
            </section>

            <section className="mt-5 rounded-xl border border-white/[0.07] bg-white/[0.025] p-4 sm:p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">
                    Afinidade elemental
                  </p>
                  <p className="mt-1 text-sm text-slate-300">
                    Três elementos em sintonia
                  </p>
                </div>
                <div className="flex h-11 w-11 items-center justify-center rounded-full border border-cyan-100/15 bg-cyan-200/[0.06] text-sm font-bold text-cyan-100">
                  3<span className="text-[10px] font-medium text-cyan-100/50">/4</span>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2">
                {elements.map(({ name, icon: Icon, primary }) => (
                  <div
                    key={name}
                    className={`rounded-lg border px-2 py-3 text-center ${
                      primary
                        ? "border-cyan-200/20 bg-cyan-200/[0.08]"
                        : "border-white/[0.07] bg-black/10"
                    }`}
                  >
                    <Icon
                      size={16}
                      className={`mx-auto ${
                        primary ? "text-cyan-100" : "text-slate-400"
                      }`}
                      strokeWidth={1.8}
                    />
                    <p className="mt-2 text-xs font-semibold text-slate-200">
                      {name}
                    </p>
                    <p className="mt-1 text-[8px] font-bold uppercase tracking-[0.14em] text-slate-500">
                      {primary ? "da vila" : "afinidade"}
                    </p>
                  </div>
                ))}
              </div>
            </section>

            <section className="mt-5 overflow-hidden rounded-xl border border-white/[0.07] bg-[#171d25]">
              <div className="flex items-center gap-3 border-b border-white/[0.06] px-4 py-3.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-300/10 text-indigo-200">
                  <Brain size={17} strokeWidth={1.8} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500">
                    Perfil intelectual
                  </p>
                  <p className="mt-0.5 text-sm font-semibold text-white">
                    Gênio <span className="font-normal text-indigo-200">· 150</span>
                  </p>
                </div>
              </div>
              <div className="px-4 py-4">
                <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-indigo-200/65">
                  Exemplo · descrição intelectual
                </p>
                <p className="mt-2 text-[13px] leading-6 text-slate-300">
                  Seu raciocínio combina leitura rápida de padrões com
                  planejamento cuidadoso. Você conecta pistas isoladas,
                  identifica pontos fracos e adapta a estratégia sem perder o
                  objetivo. Sob pressão, mantém clareza e prefere movimentos
                  calculados a reações impulsivas.
                </p>
              </div>
            </section>

            <footer className="mt-5 flex items-center justify-between border-t border-white/[0.07] pt-4">
              <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.13em] text-slate-600">
                <Swords size={13} />
                Arquivo shinobi
              </div>
              <div className="flex items-center gap-1.5 text-[10px] font-semibold text-cyan-100/65">
                REGISTRO CONCLUÍDO
                <ArrowUpRight size={12} />
              </div>
            </footer>
          </div>
        </article>

        <p className="mt-3 px-1 text-[10px] leading-5 text-slate-600">
          Prévia de layout. Os textos e cargos aplicados serão definidos na
          configuração final do bot.
        </p>
      </div>
    </main>
  );
}