---
name: Discord bot delivery
description: User-confirmed behavior for the Discord roleplay ficha bot.
---

The user confirmed that the bot's `/verficha` slash-command flow worked in their Discord server.

**Why:** This confirms that the Replit-hosted Discord client and application command registration are viable for this project.

**How to apply:** Keep commands as Discord application interactions; do not replace them with a plain-text or message-content listener.