# Bot Discord de Fichas

Bot de Discord em português que gera fichas aleatórias de personagens com o comando `/verficha`.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/api-server run bot` — run the Discord bot
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required secret for the Discord bot: `DISCORD_BOT_TOKEN`
- Bot setup and invite instructions: `DISCORD_BOT_SETUP.md`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/bot.ts` — Discord connection, `/verficha` registration, and interaction handler
- `artifacts/api-server/src/bot/ficha.ts` — random character data and Discord embed
- `DISCORD_BOT_SETUP.md` — Developer Portal, invite, and startup instructions

## Architecture decisions

- The bot uses only the standard Discord server intent; privileged message intents are not needed.
- `/verficha` and the four village-specific registration commands are registered globally; startup edits only these commands so other application commands are preserved.
- Fichas are generated on demand and are not saved between commands.
- Compatibility with a second clan is rolled as one "yes" result out of six.
- Clan draw weights are Common 8, Uncommon 12, Rare 8, Epic 6, and Legendary 4; Senko and Ashen Storm use 1.
- Element-count weights are 20/4/1 for 2/3/4 elements. Intellect category weights are 50/30/10 for Normal/Inteligente/Gênio.

## Product

- `/verficha` creates a random Portuguese-language shinobi profile; `/registroareia`, `/registrofolha`, `/registronuvem`, and `/registronévoa` generate one from a fixed village.
- Each profile rolls only that village's clans, weighted clan rarity, 2–4 elements including its main element, weighted intellect, and a chance to be compatible with two clans.
- The embed uses a full-width vertical field layout, village-specific colors, and rarity emojis.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
