# Bot de fichas do Discord

O bot responde ao `/verficha` com uma ficha de vila aleatória. Para escolher uma vila, use `/registroareia`, `/registrofolha`, `/registronuvem` ou `/registronévoa`. Todos os comandos têm o campo opcional `usuario` para gerar a ficha para outra pessoa. Cada ficha tem de 2 a 4 elementos, incluindo o elemento principal da vila.

## Adicionar o bot ao servidor

1. Abra o [Discord Developer Portal](https://discord.com/developers/applications) e crie uma aplicação.
2. Na página **Bot**, crie o bot e copie o token para o Secret `DISCORD_BOT_TOKEN` do Replit. Nunca publique o token nem o envie em mensagens.
3. Mantenha desativados os intents privilegiados. Este bot só precisa do intent padrão de servidores.
4. Inicie o workflow **Discord Bot**. No log, copie o link de convite gerado para o bot.
5. Abra o link, escolha o servidor e autorize os escopos `bot` e `applications.commands`.
6. Quando os comandos aparecerem no servidor, use `/verficha` para sortear qualquer vila ou um dos quatro comandos de registro para escolher a vila.

O convite pede permissão para enviar mensagens e embeds. Os comandos são registrados globalmente; a propagação inicial pode levar alguns minutos.